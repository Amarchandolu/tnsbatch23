package tns.day2;

public class B {
public static void main(String[] args) {
	System.out.println("this is my second program");
}
}
