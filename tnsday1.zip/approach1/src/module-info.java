/**
 * 
 */
/**
 * 
 */
module approach1 {
}