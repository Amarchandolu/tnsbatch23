package approach2;

public class B1 {

	public static void main(String[] args) {
      int c=50;
      System.out.println(c);
      A1 a1=new A1();
      System.out.println(a1.a);
      System.out.println(a1.b);
      a1.display();
      A1.display1();

	}

}
