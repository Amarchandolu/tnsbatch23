package approach2;

public class A1 {
	int a=30;
	static int b=40;
	int display() 
	{
		return 10;
	}
		static void display1() 
		{
			System.out.println(10);
			
		
	}

}
