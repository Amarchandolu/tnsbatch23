package A1;

public class private1 {
	private void display() {
		System.out.println("tns java");
	}
	public static void main(String[] args) {
		private1 a1=new private1();
		a1.display();
		
	
	}
	

}
