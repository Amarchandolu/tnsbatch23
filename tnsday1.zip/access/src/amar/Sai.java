package amar;

public class Sai {
protected void display() {
	System.out.println("heyy");
}
}
