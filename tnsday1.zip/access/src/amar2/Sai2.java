package amar2;
import amar.Sai;
public class Sai2 extends Sai {
public static void main(String[] args) {
	Sai2 a =new Sai2();
	a.display();
}
}
