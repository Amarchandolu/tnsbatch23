package defaultmain;

public class defaultmain {
void display() {
	System.out.println("tns java program");
}
public static void main(String[] args) {
	defaultmain a1=new defaultmain();
	a1.display();
	
  }
}
