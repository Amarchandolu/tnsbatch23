package public1;

public class publicmain {
	int a=40;
	public static void main(String[] args) {
		publicmain obj=new publicmain();
		System.out.println(obj.a);
	}

}
